#include <gpxe/wrap.h>
