# Nuvora 0.7.2 内存管理修复包

进入 `nuvora-core-0.7.2/` 查看源码、预编译启动镜像和测试日志。

```sh
cd nuvora-core-0.7.2
python3 start.py --memory 5120
```

UEFI 加 `--uefi`，需要宿主安装 QEMU 与 OVMF。

本轮修复连续缓冲跨 1 GiB 时的错误内存访问，以及碎片化 RAM 导致内核堆启动失败的问题。说明和失败复现见 `nuvora-core-0.7.2/docs/MEMORY-0.7.2.md`。

x64 52 组、i686 41 组完整回归和 6 组 UBSan 源码测试通过。包内包含 BIOS/UEFI ISO、ESP、ELF 与完整执行日志，不包含临时测试磁盘。

Linux 压缩包及其他原附材料保留原字节内容，不参与 Nuvora 编译或链接。根目录 SHA256SUMS 覆盖全包文件，Nuvora 子目录保留独立清单。
