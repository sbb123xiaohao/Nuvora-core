#!/usr/bin/env python3
"""Create a new Nuvora data image. Never format an existing file or device."""
import argparse
import pathlib
import struct
import zlib

# NVSTORE2 geometry: header sector, two snapshot slots of 16 MiB + 1 header
# sector each, directly adjacent. The u64 total sector count accepts images
# far beyond 2 TiB. The kernel accepts larger disks as long as they cover
# both slots.
SLOT_SECTORS = 16 * 1024 * 1024 // 512 + 1
SLOT0_LBA = 8
SLOT1_LBA = SLOT0_LBA + SLOT_SECTORS
MIN_MIB = (SLOT1_LBA + SLOT_SECTORS) * 512 // (1024 * 1024) + 1
MAX_MIB = (1 << 48) * 512 // (1024 * 1024)  # ATA LBA48, not an unlimited filesystem


def create(path: pathlib.Path, if_missing: bool = False, size_mib: int = 64):
    if path.exists() and if_missing:
        if not path.is_file():
            raise SystemExit(f'Not a regular file: {path}')
        with path.open('rb') as stream:
            magic = stream.read(8)
            if magic not in (b'NVSTORE1', b'NVSTORE2'):
                raise SystemExit(f'Refusing an unrecognized existing file: {path}')
        return
    if size_mib < MIN_MIB or size_mib > MAX_MIB:
        raise SystemExit(f'Data image size must be {MIN_MIB}..{MAX_MIB} MiB (ATA LBA48).')
    path.parent.mkdir(parents=True, exist_ok=True)
    body = b'NVSTORE2' + struct.pack('<IIIII', 2, 512, SLOT0_LBA, SLOT1_LBA, SLOT_SECTORS)
    body += struct.pack('<I', 0) + struct.pack('<Q', size_mib * 1024 * 1024 // 512)
    header = body + struct.pack('<I', zlib.crc32(body))
    with path.open('xb') as stream:
        try:
            stream.write(header.ljust(512, b'\0'))
            stream.truncate(size_mib * 1024 * 1024)
        except BaseException:
            stream.close()
            path.unlink()
            raise
    print(f'Created {size_mib} MiB Nuvora data image: {path}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path', type=pathlib.Path)
    parser.add_argument('--if-missing', action='store_true')
    parser.add_argument('--size', type=int, default=64, metavar='MIB',
                        help='image size in MiB (default: 64)')
    args = parser.parse_args()
    create(args.path, args.if_missing, args.size)
